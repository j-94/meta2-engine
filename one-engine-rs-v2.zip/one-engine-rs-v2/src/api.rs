use axum::{extract::State, Json, response::IntoResponse};
use serde::{Serialize, Deserialize};
use schemars::JsonSchema;
use utoipa::{ToSchema, OpenApi};
use crate::engine::{self, types::{Bits, Policy, Manifest}, validate};

#[derive(Clone, Default)]
pub struct AppState {}

#[derive(Debug, Serialize, Deserialize, JsonSchema, ToSchema)]
pub struct RunReq {
    pub goal_id: String,
    #[serde(default)]
    pub inputs: serde_json::Value,
    pub policy: Policy
}

#[derive(Debug, Serialize, Deserialize, JsonSchema, ToSchema)]
pub struct RunResp {
    pub manifest: Manifest,
    pub bits: Bits
}

#[derive(Debug, Serialize, Deserialize, JsonSchema, ToSchema)]
pub struct ValidateReq {
    pub suite: String, // "easy", "hard", "impossible", "adaptive"
}

#[derive(Debug, Serialize, Deserialize, JsonSchema, ToSchema)]
pub struct ValidateResp {
    pub metacognitive_score: f32,
    pub results: Vec<ValidationResult>,
    pub summary: String
}

#[derive(Debug, Serialize, Deserialize, JsonSchema, ToSchema)]
pub struct ValidationResult {
    pub task: String,
    pub expected_difficulty: f32,
    pub actual_bits: Bits,
    pub score: f32
}

#[derive(Debug, Serialize, Deserialize, JsonSchema, ToSchema)]
pub struct VersionInfo {
    pub engine: &'static str,
    pub build_token: Option<&'static str>,
    pub git_ref: Option<&'static str>,
    pub ts: String
}

impl VersionInfo {
    pub fn current() -> Self {
        let ts = chrono::Utc::now().to_rfc3339();
        Self{
            engine: env!("CARGO_PKG_VERSION"),
            build_token: option_env!("BUILD_TOKEN"),
            git_ref: option_env!("GIT_REF"),
            ts
        }
    }
}

#[utoipa::path(
    get,
    path = "/version",
    responses(
        (status = 200, description = "Engine version", body = VersionInfo)
    )
)]
pub async fn version_handler() -> impl IntoResponse {
    Json(VersionInfo::current())
}

#[utoipa::path(
    post,
    path = "/run",
    request_body = RunReq,
    responses(
        (status = 200, description = "Run completed", body = RunResp)
    )
)]
pub async fn run_handler(State(_state): State<AppState>, Json(req): Json<RunReq>) -> impl IntoResponse {
    match engine::run(&req.goal_id, req.inputs, &req.policy).await {
        Ok((manifest, bits)) => Json(RunResp{ manifest, bits }).into_response(),
        Err(e) => (axum::http::StatusCode::BAD_REQUEST, e.to_string()).into_response()
    }
}

#[utoipa::path(
    post,
    path = "/validate",
    request_body = ValidateReq,
    responses(
        (status = 200, description = "Validation completed", body = ValidateResp)
    )
)]
pub async fn validate_handler(State(_state): State<AppState>, Json(req): Json<ValidateReq>) -> impl IntoResponse {
    match validate::run_suite(&req.suite).await {
        Ok(resp) => Json(resp).into_response(),
        Err(e) => (axum::http::StatusCode::BAD_REQUEST, e.to_string()).into_response()
    }
}

#[derive(OpenApi)]
#[openapi(
    paths(version_handler, run_handler, validate_handler),
    components(schemas(Bits, Policy, Manifest, RunReq, RunResp, VersionInfo, ValidateReq, ValidateResp, ValidationResult)),
    tags((name="one-engine", description="Plan→Act→Verify engine with metacognitive validation"))
)]
pub struct ApiDoc;
