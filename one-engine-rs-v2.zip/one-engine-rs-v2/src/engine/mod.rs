pub mod bits;
pub mod types;
pub mod executor;
pub mod verify;
pub mod policy;
pub mod validate;

use types::{Manifest, Bits, Policy};
use uuid::Uuid;

pub async fn run(goal_id: &str, inputs: serde_json::Value, policy: &Policy) -> anyhow::Result<(Manifest, Bits)> {
    let mut bits = Bits::init();
    
    // Set uncertainty based on goal difficulty
    bits.u = match goal_id {
        id if id.contains("easy") => 0.1,
        id if id.contains("hard") => 0.7,
        id if id.contains("impossible") => 0.9,
        _ => 0.3
    };
    
    let message = inputs.get("message").and_then(|v| v.as_str()).unwrap_or("hello from one-engine");
    
    // Simulate different outcomes based on goal type
    let (action, expected_success) = match goal_id {
        id if id.contains("impossible") => (executor::Action::Cli("false".to_string()), false),
        id if id.contains("hard") => (executor::Action::Cli(format!("sleep 0.1 && echo {}", shell_escape::escape(message.into()))), true),
        _ => (executor::Action::Cli(format!("echo {}", shell_escape::escape(message.into()))), true)
    };
    
    let res = executor::execute(action, policy).await?;
    
    if res.drift { bits.d = 1.0; }
    if !res.ok { 
        bits.e = 1.0;
        // Increase uncertainty for future similar tasks
        bits.u = (bits.u + 0.2).min(1.0);
    }
    
    let passed = verify::check_minimal(&res);
    bits.t = policy::trust_from(passed, &bits);
    
    // Adjust trust based on expectation vs reality
    if expected_success != passed {
        bits.t *= 0.7; // Lower trust when predictions are wrong
    }
    
    let manifest = types::Manifest {
        run_id: format!("r-{}", Uuid::new_v4()),
        goal_id: goal_id.to_string(),
        deliverables: vec![],
        evidence: serde_json::json!({ 
            "stdout": res.stdout,
            "expected_success": expected_success,
            "actual_success": passed
        }),
        bits: bits.clone()
    };
    
    Ok((manifest, bits))
}
