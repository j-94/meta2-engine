mod api;
mod engine;

use axum::{Router, routing::{get, post}};
use tracing_subscriber::{fmt, EnvFilter};
use utoipa::OpenApi;
use utoipa_swagger_ui::SwaggerUi;

#[tokio::main]
async fn main() -> anyhow::Result<()> {
    let env_filter = EnvFilter::try_from_default_env().unwrap_or_else(|_| EnvFilter::new("info"));
    fmt().with_env_filter(env_filter).init();

    let state = api::AppState::default();
    let openapi = api::ApiDoc::openapi();

    let app = Router::new()
        .route("/health", get(|| async { "ok" }))
        .route("/version", get(api::version_handler))
        .route("/run", post(api::run_handler))
        .route("/validate", post(api::validate_handler))
        .merge(SwaggerUi::new("/swagger-ui").url("/api-docs/openapi.json", openapi))
        .with_state(state);

    let addr = std::net::SocketAddr::from(([127,0,0,1], 8080));
    tracing::info!("listening on http://{addr}");
    axum::Server::bind(&addr).serve(app.into_make_service()).await?;
    Ok(())
}
